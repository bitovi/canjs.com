$(function () {
	$('#can-main').html('The Requisite “Hello World” Message');
});