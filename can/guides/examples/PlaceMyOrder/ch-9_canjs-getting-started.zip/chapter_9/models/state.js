var State = can.Model.extend({
	findAll: 'GET /api/states'
}, {
	// Include second, empty parameter object to set instanceProperties
});